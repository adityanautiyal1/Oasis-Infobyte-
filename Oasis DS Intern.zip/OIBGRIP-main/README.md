# OASIS INFOBYTE INTERNSHIP


This internship was all about data science and analytics. I applied for this internship from the website of Oasis Infobyte. 
I completed all the given tasks by them. They have given 5 tasks.
The description of all the tasks is given below:

Task-1: IRIS FLOWER CLASSIFICATION
I predicted the species of IRIS Flower using the attributes given such as: petal length, sepal length, petal width and sepal width. 
I used Decision Tree classification(ID3 Classifier) for classification of species.

Task-2: UNEMPLOYMENT ANALYSIS
I explored the dataset by creating various charts and graphs using matplotlib and seaborn libraries of python for unemployment analysis.

TASK-3 CAR PRICE PREDICTION USING MACHINE LEARNING
The price of a car depends on a lot of factors like the good will of the brand of the car, features of the car, horoscope and the milage it gives and many more. Car
price prediction is one of the major research areas in machine learning. So if you want to learn how to train a car price prediction model then this project is for you.

Task-4: EMAIL SPAM DETECTION
We have all been the recipient of spam mails before. Spam mail,or junk mail, is a type of email that is sent to a massive number of users at one time, frequently containing cryptic messages, scams ,or most dangerously, phishing content.
        In this project , we use Python to build an email spam detector. Then use machine learning to train the spam detector to recognize and classify emails into spam and non-spam.
        
Task-5: SALES PREDICTION
Sales prediction means predicting how much of a product people will buy based on factors such as the amount you spend to advertise your product, the segment of 
people you advertise for, or the platform you are advertising on about your product. Typically, a product and service-based business always need their Data Scientist 
to predict their future sales with every step they take to manipulate the cost of advertising their product. The task of sales prediction with machine learning id done 
using python.I used linear regression model for forecasting the sales.



